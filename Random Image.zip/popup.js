const button=document.getElementById('button');

function reload(){
    location.reload();
}

button.addEventListener('click',()=>{
    location.reload();
})